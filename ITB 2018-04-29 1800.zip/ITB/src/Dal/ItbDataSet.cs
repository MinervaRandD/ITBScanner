﻿namespace Asi.Itb.Dal {
    
    
    public partial class ItbDataSet {
        partial class ScanDataTable
        {
        }
    
        partial class LocalVariablesDataTable
        {
        }
    
        partial class UserDataTable
        {
        }
    }
}
