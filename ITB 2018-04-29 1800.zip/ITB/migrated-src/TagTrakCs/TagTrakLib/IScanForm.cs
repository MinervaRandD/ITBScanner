namespace TagTrak.TagTrakLib
{
	public interface IScanForm
	{

		void ProcessScanData(string readerString);
	}
}
