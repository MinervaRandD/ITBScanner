﻿namespace Asi.Itb.UI
{
    partial class BagDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.barcodeLabel = new System.Windows.Forms.Label();
            this.barcodeTextBox = new System.Windows.Forms.TextBox();
            this.inboundCarrierLabel = new System.Windows.Forms.Label();
            this.outboundCarrierLabel = new System.Windows.Forms.Label();
            this.inboundCarrierTextBox = new System.Windows.Forms.TextBox();
            this.outboundCarrierTextBox = new System.Windows.Forms.TextBox();
            this.scansLabel = new System.Windows.Forms.Label();
            this.scansListView = new System.Windows.Forms.ListView();
            this.timeColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.operationColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.locationColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.destLocationLabel = new System.Windows.Forms.Label();
            this.destTextBox = new System.Windows.Forms.TextBox();
            this.onhandTimeLabel = new System.Windows.Forms.Label();
            this.onhandTimeTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // barcodeLabel
            // 
            this.barcodeLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.barcodeLabel.Location = new System.Drawing.Point(7, 68);
            this.barcodeLabel.Name = "barcodeLabel";
            this.barcodeLabel.Size = new System.Drawing.Size(110, 20);
            this.barcodeLabel.Text = "Barcode";
            // 
            // barcodeTextBox
            // 
            this.barcodeTextBox.Location = new System.Drawing.Point(120, 67);
            this.barcodeTextBox.Name = "barcodeTextBox";
            this.barcodeTextBox.ReadOnly = true;
            this.barcodeTextBox.Size = new System.Drawing.Size(107, 21);
            this.barcodeTextBox.TabIndex = 1;
            // 
            // inboundCarrierLabel
            // 
            this.inboundCarrierLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.inboundCarrierLabel.Location = new System.Drawing.Point(7, 93);
            this.inboundCarrierLabel.Name = "inboundCarrierLabel";
            this.inboundCarrierLabel.Size = new System.Drawing.Size(110, 20);
            this.inboundCarrierLabel.Text = "Inbound Carrier";
            // 
            // outboundCarrierLabel
            // 
            this.outboundCarrierLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.outboundCarrierLabel.Location = new System.Drawing.Point(7, 117);
            this.outboundCarrierLabel.Name = "outboundCarrierLabel";
            this.outboundCarrierLabel.Size = new System.Drawing.Size(124, 20);
            this.outboundCarrierLabel.Text = "Outbound Carrier";
            // 
            // inboundCarrierTextBox
            // 
            this.inboundCarrierTextBox.Location = new System.Drawing.Point(120, 91);
            this.inboundCarrierTextBox.Name = "inboundCarrierTextBox";
            this.inboundCarrierTextBox.ReadOnly = true;
            this.inboundCarrierTextBox.Size = new System.Drawing.Size(107, 21);
            this.inboundCarrierTextBox.TabIndex = 4;
            // 
            // outboundCarrierTextBox
            // 
            this.outboundCarrierTextBox.Location = new System.Drawing.Point(120, 115);
            this.outboundCarrierTextBox.Name = "outboundCarrierTextBox";
            this.outboundCarrierTextBox.ReadOnly = true;
            this.outboundCarrierTextBox.Size = new System.Drawing.Size(107, 21);
            this.outboundCarrierTextBox.TabIndex = 5;
            // 
            // scansLabel
            // 
            this.scansLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.scansLabel.Location = new System.Drawing.Point(8, 187);
            this.scansLabel.Name = "scansLabel";
            this.scansLabel.Size = new System.Drawing.Size(110, 20);
            this.scansLabel.Text = "Scans";
            // 
            // scansListView
            // 
            this.scansListView.Columns.Add(this.timeColumnHeader);
            this.scansListView.Columns.Add(this.operationColumnHeader);
            this.scansListView.Columns.Add(this.locationColumnHeader);
            this.scansListView.Location = new System.Drawing.Point(8, 206);
            this.scansListView.Name = "scansListView";
            this.scansListView.Size = new System.Drawing.Size(220, 94);
            this.scansListView.TabIndex = 7;
            this.scansListView.View = System.Windows.Forms.View.Details;
            // 
            // timeColumnHeader
            // 
            this.timeColumnHeader.Text = "Time";
            this.timeColumnHeader.Width = 72;
            // 
            // operationColumnHeader
            // 
            this.operationColumnHeader.Text = "Operation";
            this.operationColumnHeader.Width = 82;
            // 
            // locationColumnHeader
            // 
            this.locationColumnHeader.Text = "Location";
            this.locationColumnHeader.Width = 64;
            // 
            // destLocationLabel
            // 
            this.destLocationLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.destLocationLabel.Location = new System.Drawing.Point(8, 141);
            this.destLocationLabel.Name = "destLocationLabel";
            this.destLocationLabel.Size = new System.Drawing.Size(100, 20);
            this.destLocationLabel.Text = "Destination";
            // 
            // destTextBox
            // 
            this.destTextBox.Location = new System.Drawing.Point(120, 139);
            this.destTextBox.Name = "destTextBox";
            this.destTextBox.ReadOnly = true;
            this.destTextBox.Size = new System.Drawing.Size(107, 21);
            this.destTextBox.TabIndex = 13;
            // 
            // onhandTimeLabel
            // 
            this.onhandTimeLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.onhandTimeLabel.Location = new System.Drawing.Point(8, 166);
            this.onhandTimeLabel.Name = "onhandTimeLabel";
            this.onhandTimeLabel.Size = new System.Drawing.Size(100, 20);
            this.onhandTimeLabel.Text = "On Hand Time";
            // 
            // onhandTimeTextBox
            // 
            this.onhandTimeTextBox.Location = new System.Drawing.Point(120, 166);
            this.onhandTimeTextBox.Name = "onhandTimeTextBox";
            this.onhandTimeTextBox.ReadOnly = true;
            this.onhandTimeTextBox.Size = new System.Drawing.Size(107, 21);
            this.onhandTimeTextBox.TabIndex = 21;
            // 
            // BagDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 320);
            this.Controls.Add(this.onhandTimeTextBox);
            this.Controls.Add(this.onhandTimeLabel);
            this.Controls.Add(this.destTextBox);
            this.Controls.Add(this.destLocationLabel);
            this.Controls.Add(this.scansListView);
            this.Controls.Add(this.scansLabel);
            this.Controls.Add(this.outboundCarrierTextBox);
            this.Controls.Add(this.inboundCarrierTextBox);
            this.Controls.Add(this.outboundCarrierLabel);
            this.Controls.Add(this.inboundCarrierLabel);
            this.Controls.Add(this.barcodeTextBox);
            this.Controls.Add(this.barcodeLabel);
            this.ExitPictureBoxVisible = true;
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "BagDetailForm";
            this.Text = "BagDetailForm";
            this.TitleLabelText = "Bag Detail";
            this.TitleLabelVisible = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label barcodeLabel;
        private System.Windows.Forms.TextBox barcodeTextBox;
        private System.Windows.Forms.Label inboundCarrierLabel;
        private System.Windows.Forms.Label outboundCarrierLabel;
        private System.Windows.Forms.TextBox inboundCarrierTextBox;
        private System.Windows.Forms.TextBox outboundCarrierTextBox;
        private System.Windows.Forms.Label scansLabel;
        private System.Windows.Forms.ListView scansListView;
        private System.Windows.Forms.ColumnHeader timeColumnHeader;
        private System.Windows.Forms.ColumnHeader operationColumnHeader;
        private System.Windows.Forms.ColumnHeader locationColumnHeader;
        private System.Windows.Forms.Label destLocationLabel;
        private System.Windows.Forms.TextBox destTextBox;
        private System.Windows.Forms.Label onhandTimeLabel;
        private System.Windows.Forms.TextBox onhandTimeTextBox;
    }
}