﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Asi.Itb.UI
{
    public partial class StatusForm : BaseForm
    {
        public StatusForm()
        {
            InitializeComponent();
        }
    }
}