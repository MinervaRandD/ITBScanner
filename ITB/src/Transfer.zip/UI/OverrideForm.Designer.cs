﻿namespace Asi.Itb.UI
{
    partial class OverrideForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.locationLabel = new System.Windows.Forms.Label();
            this.locationComboBox = new System.Windows.Forms.ComboBox();
            this.codeComboBox = new System.Windows.Forms.ComboBox();
            this.codeLabel = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.gateLabel = new System.Windows.Forms.Label();
            this.gateTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // locationLabel
            // 
            this.locationLabel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.locationLabel.Location = new System.Drawing.Point(8, 84);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(86, 20);
            this.locationLabel.Text = "Location";
            // 
            // locationComboBox
            // 
            this.locationComboBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.locationComboBox.Location = new System.Drawing.Point(81, 82);
            this.locationComboBox.Name = "locationComboBox";
            this.locationComboBox.Size = new System.Drawing.Size(146, 20);
            this.locationComboBox.TabIndex = 1;
            this.locationComboBox.SelectedIndexChanged += new System.EventHandler(this.locationComboBox_SelectedIndexChanged);
            // 
            // codeComboBox
            // 
            this.codeComboBox.Items.Add("Carrier Drop Off");
            this.codeComboBox.Items.Add("Carrier Pick Up");
            this.codeComboBox.Items.Add("Handler Pick Up");
            this.codeComboBox.Items.Add("Handler Drop Off");
            this.codeComboBox.Items.Add("Gate Pick Up");
            this.codeComboBox.Items.Add("Gate Drop Off");
            this.codeComboBox.Items.Add("Overnight In");
            this.codeComboBox.Items.Add("Overnight Out");
            this.codeComboBox.Location = new System.Drawing.Point(81, 115);
            this.codeComboBox.Name = "codeComboBox";
            this.codeComboBox.Size = new System.Drawing.Size(146, 22);
            this.codeComboBox.TabIndex = 3;
            this.codeComboBox.SelectedIndexChanged += new System.EventHandler(this.codeComboBox_SelectedIndexChanged);
            // 
            // codeLabel
            // 
            this.codeLabel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.codeLabel.Location = new System.Drawing.Point(8, 117);
            this.codeLabel.Name = "codeLabel";
            this.codeLabel.Size = new System.Drawing.Size(86, 20);
            this.codeLabel.Text = "Code";
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.saveButton.Location = new System.Drawing.Point(81, 219);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(72, 25);
            this.saveButton.TabIndex = 11;
            this.saveButton.Text = "Save";
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // gateLabel
            // 
            this.gateLabel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.gateLabel.Location = new System.Drawing.Point(8, 157);
            this.gateLabel.Name = "gateLabel";
            this.gateLabel.Size = new System.Drawing.Size(86, 20);
            this.gateLabel.Text = "Gate";
            this.gateLabel.Visible = false;
            // 
            // gateTextBox
            // 
            this.gateTextBox.Location = new System.Drawing.Point(81, 155);
            this.gateTextBox.Name = "gateTextBox";
            this.gateTextBox.Size = new System.Drawing.Size(146, 21);
            this.gateTextBox.TabIndex = 15;
            this.gateTextBox.Visible = false;
            // 
            // OverrideForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(240, 294);
            this.Controls.Add(this.gateTextBox);
            this.Controls.Add(this.gateLabel);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.codeComboBox);
            this.Controls.Add(this.codeLabel);
            this.Controls.Add(this.locationComboBox);
            this.Controls.Add(this.locationLabel);
            this.ExitPictureBoxVisible = true;
            this.Location = new System.Drawing.Point(0, 0);
            this.Menu = this.mainMenu1;
            this.Name = "OverrideForm";
            this.Text = "Location/Scan Override";
            this.TitleLabelText = "Override";
            this.TitleLabelVisible = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.ComboBox locationComboBox;
        private System.Windows.Forms.ComboBox codeComboBox;
        private System.Windows.Forms.Label codeLabel;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Label gateLabel;
        private System.Windows.Forms.TextBox gateTextBox;
    }
}