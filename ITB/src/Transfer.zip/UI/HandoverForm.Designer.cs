﻿namespace Asi.Itb.UI
{
    partial class HandoverForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.locTextBox = new System.Windows.Forms.TextBox();
            this.locLabel = new System.Windows.Forms.Label();
            this.syncStatusPanel = new System.Windows.Forms.Panel();
            this.syncStatusLabel = new System.Windows.Forms.Label();
            this.syncProgressBar = new System.Windows.Forms.ProgressBar();
            this.addButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.addLabel = new System.Windows.Forms.Label();
            this.sendButton = new System.Windows.Forms.Button();
            this.locColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.latColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.longColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.locListView = new System.Windows.Forms.ListView();
            this.typeColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.removeButton = new System.Windows.Forms.Button();
            this.addProgressBar = new System.Windows.Forms.ProgressBar();
            this.loctypeComboBox = new System.Windows.Forms.ComboBox();
            this.syncStatusPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // locTextBox
            // 
            this.locTextBox.Location = new System.Drawing.Point(118, 70);
            this.locTextBox.MaxLength = 20;
            this.locTextBox.Name = "locTextBox";
            this.locTextBox.Size = new System.Drawing.Size(118, 21);
            this.locTextBox.TabIndex = 0;
            // 
            // locLabel
            // 
            this.locLabel.Location = new System.Drawing.Point(5, 72);
            this.locLabel.Name = "locLabel";
            this.locLabel.Size = new System.Drawing.Size(54, 20);
            this.locLabel.Text = "Location";
            // 
            // syncStatusPanel
            // 
            this.syncStatusPanel.Controls.Add(this.syncStatusLabel);
            this.syncStatusPanel.Controls.Add(this.syncProgressBar);
            this.syncStatusPanel.Location = new System.Drawing.Point(3, 291);
            this.syncStatusPanel.Name = "syncStatusPanel";
            this.syncStatusPanel.Size = new System.Drawing.Size(234, 26);
            this.syncStatusPanel.Visible = false;
            // 
            // syncStatusLabel
            // 
            this.syncStatusLabel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.syncStatusLabel.ForeColor = System.Drawing.SystemColors.GrayText;
            this.syncStatusLabel.Location = new System.Drawing.Point(3, 2);
            this.syncStatusLabel.Name = "syncStatusLabel";
            this.syncStatusLabel.Size = new System.Drawing.Size(228, 11);
            // 
            // syncProgressBar
            // 
            this.syncProgressBar.Location = new System.Drawing.Point(0, 15);
            this.syncProgressBar.Name = "syncProgressBar";
            this.syncProgressBar.Size = new System.Drawing.Size(234, 10);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(130, 94);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(51, 17);
            this.addButton.TabIndex = 5;
            this.addButton.Text = "Add";
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.cancelButton.Location = new System.Drawing.Point(185, 94);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(51, 17);
            this.cancelButton.TabIndex = 6;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // addLabel
            // 
            this.addLabel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.addLabel.ForeColor = System.Drawing.Color.Gray;
            this.addLabel.Location = new System.Drawing.Point(5, 95);
            this.addLabel.Name = "addLabel";
            this.addLabel.Size = new System.Drawing.Size(118, 14);
            this.addLabel.Text = "Calculating...";
            // 
            // sendButton
            // 
            this.sendButton.Location = new System.Drawing.Point(164, 295);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(72, 17);
            this.sendButton.TabIndex = 10;
            this.sendButton.Text = "Send";
            this.sendButton.Click += new System.EventHandler(this.sendButton_Click);
            // 
            // locColumnHeader
            // 
            this.locColumnHeader.Text = "Location";
            this.locColumnHeader.Width = 104;
            // 
            // latColumnHeader
            // 
            this.latColumnHeader.Text = "Lat";
            this.latColumnHeader.Width = 44;
            // 
            // longColumnHeader
            // 
            this.longColumnHeader.Text = "Long";
            this.longColumnHeader.Width = 44;
            // 
            // locListView
            // 
            this.locListView.Columns.Add(this.typeColumnHeader);
            this.locListView.Columns.Add(this.locColumnHeader);
            this.locListView.Columns.Add(this.latColumnHeader);
            this.locListView.Columns.Add(this.longColumnHeader);
            this.locListView.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.locListView.FullRowSelect = true;
            this.locListView.Location = new System.Drawing.Point(3, 122);
            this.locListView.Name = "locListView";
            this.locListView.Size = new System.Drawing.Size(233, 167);
            this.locListView.TabIndex = 8;
            this.locListView.View = System.Windows.Forms.View.Details;
            this.locListView.SelectedIndexChanged += new System.EventHandler(this.locListView_SelectedIndexChanged);
            // 
            // typeColumnHeader
            // 
            this.typeColumnHeader.Text = "Type";
            this.typeColumnHeader.Width = 55;
            // 
            // removeButton
            // 
            this.removeButton.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.removeButton.Location = new System.Drawing.Point(3, 295);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(51, 17);
            this.removeButton.TabIndex = 11;
            this.removeButton.Text = "Delete";
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // addProgressBar
            // 
            this.addProgressBar.Location = new System.Drawing.Point(3, 113);
            this.addProgressBar.Name = "addProgressBar";
            this.addProgressBar.Size = new System.Drawing.Size(233, 6);
            this.addProgressBar.Visible = false;
            // 
            // loctypeComboBox
            // 
            this.loctypeComboBox.Items.Add("Pickup");
            this.loctypeComboBox.Items.Add("Dropoff");
            this.loctypeComboBox.Location = new System.Drawing.Point(56, 70);
            this.loctypeComboBox.Name = "loctypeComboBox";
            this.loctypeComboBox.Size = new System.Drawing.Size(60, 22);
            this.loctypeComboBox.TabIndex = 16;
            // 
            // HandoverForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(240, 320);
            this.Controls.Add(this.loctypeComboBox);
            this.Controls.Add(this.addLabel);
            this.Controls.Add(this.locListView);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.syncStatusPanel);
            this.Controls.Add(this.addProgressBar);
            this.Controls.Add(this.locLabel);
            this.Controls.Add(this.locTextBox);
            this.Controls.Add(this.removeButton);
            this.Controls.Add(this.sendButton);
            this.ExitPictureBoxVisible = true;
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "HandoverForm";
            this.Text = "HandoverForm";
            this.TitleLabelText = "Add Locations";
            this.TitleLabelVisible = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.syncStatusPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox locTextBox;
        private System.Windows.Forms.Label locLabel;
        private System.Windows.Forms.Panel syncStatusPanel;
        private System.Windows.Forms.Label syncStatusLabel;
        private System.Windows.Forms.ProgressBar syncProgressBar;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Label addLabel;
        private System.Windows.Forms.Button sendButton;
        private System.Windows.Forms.ColumnHeader locColumnHeader;
        private System.Windows.Forms.ColumnHeader latColumnHeader;
        private System.Windows.Forms.ColumnHeader longColumnHeader;
        private System.Windows.Forms.ListView locListView;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.ProgressBar addProgressBar;
        private System.Windows.Forms.ComboBox loctypeComboBox;
        private System.Windows.Forms.ColumnHeader typeColumnHeader;
    }
}