﻿namespace Asi.Itb.UI
{
    partial class MessageDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.contentTextBox = new System.Windows.Forms.TextBox();
            this.subjectLabel = new System.Windows.Forms.Label();
            this.subjectTextLabel = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            this.TimeTextLabel = new System.Windows.Forms.Label();
            this.replyLinkLabel = new System.Windows.Forms.LinkLabel();
            this.deleteLinkLabel = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // contentTextBox
            // 
            this.contentTextBox.Location = new System.Drawing.Point(3, 114);
            this.contentTextBox.Multiline = true;
            this.contentTextBox.Name = "contentTextBox";
            this.contentTextBox.ReadOnly = true;
            this.contentTextBox.Size = new System.Drawing.Size(234, 203);
            this.contentTextBox.TabIndex = 3;
            // 
            // subjectLabel
            // 
            this.subjectLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.subjectLabel.Location = new System.Drawing.Point(4, 68);
            this.subjectLabel.Name = "subjectLabel";
            this.subjectLabel.Size = new System.Drawing.Size(55, 20);
            this.subjectLabel.Text = "Subject";
            // 
            // subjectTextLabel
            // 
            this.subjectTextLabel.Location = new System.Drawing.Point(65, 68);
            this.subjectTextLabel.Name = "subjectTextLabel";
            this.subjectTextLabel.Size = new System.Drawing.Size(172, 20);
            // 
            // timeLabel
            // 
            this.timeLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.timeLabel.Location = new System.Drawing.Point(3, 88);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(55, 20);
            this.timeLabel.Text = "Time";
            // 
            // TimeTextLabel
            // 
            this.TimeTextLabel.Location = new System.Drawing.Point(65, 88);
            this.TimeTextLabel.Name = "TimeTextLabel";
            this.TimeTextLabel.Size = new System.Drawing.Size(124, 20);
            // 
            // replyLinkLabel
            // 
            this.replyLinkLabel.Enabled = false;
            this.replyLinkLabel.Location = new System.Drawing.Point(189, 68);
            this.replyLinkLabel.Name = "replyLinkLabel";
            this.replyLinkLabel.Size = new System.Drawing.Size(42, 20);
            this.replyLinkLabel.TabIndex = 4;
            this.replyLinkLabel.Text = "Reply";
            // 
            // deleteLinkLabel
            // 
            this.deleteLinkLabel.Location = new System.Drawing.Point(189, 88);
            this.deleteLinkLabel.Name = "deleteLinkLabel";
            this.deleteLinkLabel.Size = new System.Drawing.Size(50, 20);
            this.deleteLinkLabel.TabIndex = 9;
            this.deleteLinkLabel.Text = "Delete";
            this.deleteLinkLabel.Click += new System.EventHandler(this.deleteLinkLabel_Click);
            // 
            // MessageDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(240, 320);
            this.Controls.Add(this.deleteLinkLabel);
            this.Controls.Add(this.replyLinkLabel);
            this.Controls.Add(this.TimeTextLabel);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.subjectTextLabel);
            this.Controls.Add(this.subjectLabel);
            this.Controls.Add(this.contentTextBox);
            this.ExitPictureBoxVisible = true;
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "MessageDetailForm";
            this.Text = "MessageDetailForm";
            this.TitleLabelText = "Message Detail";
            this.TitleLabelVisible = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox contentTextBox;
        private System.Windows.Forms.Label subjectLabel;
        private System.Windows.Forms.Label subjectTextLabel;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label TimeTextLabel;
        private System.Windows.Forms.LinkLabel replyLinkLabel;
        private System.Windows.Forms.LinkLabel deleteLinkLabel;
    }
}