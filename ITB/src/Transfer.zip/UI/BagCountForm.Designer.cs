﻿namespace Asi.Itb.UI
{
    partial class BagCountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bagsListView = new System.Windows.Forms.ListView();
            this.barcodeColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.destColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // bagsListView
            // 
            this.bagsListView.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.bagsListView.Columns.Add(this.barcodeColumnHeader);
            this.bagsListView.Columns.Add(this.destColumnHeader);
            this.bagsListView.FullRowSelect = true;
            this.bagsListView.Location = new System.Drawing.Point(3, 65);
            this.bagsListView.Name = "bagsListView";
            this.bagsListView.Size = new System.Drawing.Size(234, 252);
            this.bagsListView.TabIndex = 3;
            this.bagsListView.View = System.Windows.Forms.View.Details;
            this.bagsListView.ItemActivate += new System.EventHandler(this.bagsListView_ItemActivate);
            // 
            // barcodeColumnHeader
            // 
            this.barcodeColumnHeader.Text = "Barcode";
            this.barcodeColumnHeader.Width = 120;
            // 
            // destColumnHeader
            // 
            this.destColumnHeader.Text = "Destination";
            this.destColumnHeader.Width = 110;
            // 
            // BagCountForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(240, 320);
            this.Controls.Add(this.bagsListView);
            this.ExitPictureBoxVisible = true;
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "BagCountForm";
            this.Text = "BagCountDetailForm";
            this.TitleLabelText = "";
            this.TitleLabelVisible = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView bagsListView;
        private System.Windows.Forms.ColumnHeader barcodeColumnHeader;
        private System.Windows.Forms.ColumnHeader destColumnHeader;
    }
}