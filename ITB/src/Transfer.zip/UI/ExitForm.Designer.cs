﻿namespace Asi.Itb.UI
{
    partial class ExitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.exitCodeTextBox = new System.Windows.Forms.TextBox();
            this.exitCodeLabel = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // exitCodeTextBox
            // 
            this.exitCodeTextBox.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.exitCodeTextBox.Location = new System.Drawing.Point(34, 153);
            this.exitCodeTextBox.Name = "exitCodeTextBox";
            this.exitCodeTextBox.Size = new System.Drawing.Size(173, 24);
            this.exitCodeTextBox.TabIndex = 0;
            // 
            // exitCodeLabel
            // 
            this.exitCodeLabel.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.exitCodeLabel.Location = new System.Drawing.Point(34, 98);
            this.exitCodeLabel.Name = "exitCodeLabel";
            this.exitCodeLabel.Size = new System.Drawing.Size(173, 37);
            this.exitCodeLabel.Text = "Please enter Exit Code and tap Submit";
            // 
            // submitButton
            // 
            this.submitButton.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.submitButton.Location = new System.Drawing.Point(84, 200);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(72, 26);
            this.submitButton.TabIndex = 2;
            this.submitButton.Text = "Submit";
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // ExitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 294);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.exitCodeLabel);
            this.Controls.Add(this.exitCodeTextBox);
            this.ExitPictureBoxVisible = true;
            this.Location = new System.Drawing.Point(0, 0);
            this.Menu = this.mainMenu1;
            this.Name = "ExitForm";
            this.Text = "ExitForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox exitCodeTextBox;
        private System.Windows.Forms.Label exitCodeLabel;
        private System.Windows.Forms.Button submitButton;
    }
}