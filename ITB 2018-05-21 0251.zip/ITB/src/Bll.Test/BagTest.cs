﻿using Asi.Itb.Bll.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace Bll.Test
{
    
    
    /// <summary>
    ///This is a test class for BagTest and is intended
    ///to contain all BagTest Unit Tests
    ///</summary>
    [TestClass()]
    public class BagTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for OutboundCarrier
        ///</summary>
        [TestMethod()]
        public void OutboundCarrierTest()
        {
            Bag target = new Bag(); // TODO: Initialize to an appropriate value
            string expected = string.Empty; // TODO: Initialize to an appropriate value
            string actual;
            target.OutboundCarrier = expected;
            actual = target.OutboundCarrier;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for InboundCarrier
        ///</summary>
        [TestMethod()]
        public void InboundCarrierTest()
        {
            Bag target = new Bag(); // TODO: Initialize to an appropriate value
            string expected = string.Empty; // TODO: Initialize to an appropriate value
            string actual;
            target.InboundCarrier = expected;
            actual = target.InboundCarrier;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for DestinationLocationCode
        ///</summary>
        [TestMethod()]
        public void DestinationLocationCodeTest()
        {
            Bag target = new Bag(); // TODO: Initialize to an appropriate value
            string expected = string.Empty; // TODO: Initialize to an appropriate value
            string actual;
            target.DestinationLocationCode = expected;
            actual = target.DestinationLocationCode;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Barcode
        ///</summary>
        [TestMethod()]
        public void BarcodeTest()
        {
            Bag target = new Bag(); // TODO: Initialize to an appropriate value
            string expected = string.Empty; // TODO: Initialize to an appropriate value
            string actual;
            target.Barcode = expected;
            actual = target.Barcode;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Bag Constructor
        ///</summary>
        [TestMethod()]
        public void BagConstructorTest()
        {
            Bag target = new Bag();
            Assert.Inconclusive("TODO: Implement code to verify target");
        }
    }
}
