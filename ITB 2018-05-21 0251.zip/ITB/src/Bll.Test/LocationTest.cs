﻿using Asi.Itb.Bll.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace Bll.Test
{
    
    
    /// <summary>
    ///This is a test class for LocationTest and is intended
    ///to contain all LocationTest Unit Tests
    ///</summary>
    [TestClass()]
    public class LocationTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Source
        ///</summary>
        [TestMethod()]
        public void SourceTest()
        {
            Location target = new Location(); // TODO: Initialize to an appropriate value
            LocationSource expected = new LocationSource(); // TODO: Initialize to an appropriate value
            LocationSource actual;
            target.Source = expected;
            actual = target.Source;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for OperationCode
        ///</summary>
        [TestMethod()]
        public void OperationCodeTest()
        {
            Location target = new Location(); // TODO: Initialize to an appropriate value
            Scan.ScanOperation expected = new Scan.ScanOperation(); // TODO: Initialize to an appropriate value
            Scan.ScanOperation actual;
            target.OperationCode = expected;
            actual = target.OperationCode;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Longitude
        ///</summary>
        [TestMethod()]
        public void LongitudeTest()
        {
            Location target = new Location(); // TODO: Initialize to an appropriate value
            double expected = 0F; // TODO: Initialize to an appropriate value
            double actual;
            target.Longitude = expected;
            actual = target.Longitude;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Latitude
        ///</summary>
        [TestMethod()]
        public void LatitudeTest()
        {
            Location target = new Location(); // TODO: Initialize to an appropriate value
            double expected = 0F; // TODO: Initialize to an appropriate value
            double actual;
            target.Latitude = expected;
            actual = target.Latitude;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Carriers
        ///</summary>
        [TestMethod()]
        public void CarriersTest()
        {
            Location target = new Location(); // TODO: Initialize to an appropriate value
            List<string> expected = null; // TODO: Initialize to an appropriate value
            List<string> actual;
            target.Carriers = expected;
            actual = target.Carriers;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Barcode
        ///</summary>
        [TestMethod()]
        public void BarcodeTest()
        {
            Location target = new Location(); // TODO: Initialize to an appropriate value
            string expected = string.Empty; // TODO: Initialize to an appropriate value
            string actual;
            target.Barcode = expected;
            actual = target.Barcode;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Location Constructor
        ///</summary>
        [TestMethod()]
        public void LocationConstructorTest()
        {
            Location target = new Location();
            Assert.Inconclusive("TODO: Implement code to verify target");
        }
    }
}
