using System;

namespace TagTrak.TagTrakLib
{
	/// <summary>
	/// Summary description for Carrier.
	/// </summary>
	public struct CarrierAttributes
	{
		public bool HasMail;
		public bool HasInternational;
		public bool HasCargo;
		public bool HasBaggage;
	}
}
