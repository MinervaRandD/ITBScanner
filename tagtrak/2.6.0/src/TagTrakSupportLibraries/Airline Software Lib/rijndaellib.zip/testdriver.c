#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rijndael.h"

char *y = "abcdefghijklmnopqrstuvwxyz" ;

unsigned char cryptBuff[4096 * 16] ;

unsigned char inputBuff[1024] ;
unsigned char outputBuff[1024 * 1024] ;

int aesEncrypt(
    const char *inputMode,
    const UINT8 *inputBuffer,
    const int inputLen,
    unsigned char *outputBuffer,
    const unsigned char *key, int inputKeyLength) ;

int aesDecrypt(
    const char *inputMode,
    const UINT8 *inputBuffer,
    const int inputLen,
    unsigned char *outputBuffer,
    const unsigned char *key, int inputKeyLength) ;

int main(int argc, char *argv[])
{
  Rijndael re, rd ;

  const unsigned char *z = (unsigned char *) y ;

  int rc ;

  rc = rd.init(Rijndael::ECB, Rijndael::Decrypt, z, Rijndael::Key16Bytes, (UINT8 *) 0 ) ;

  while (1)
  {
      printf("Enter string to encrypt: ") ;

      fgets((char *) inputBuff, sizeof(inputBuff) - 1, stdin) ;

      int bufflen = aesEncrypt("ECB", inputBuff, strlen((char *) inputBuff) + 1, cryptBuff, z, 16 * 8);

      rc = aesDecrypt("ECB", cryptBuff, bufflen, outputBuff, z, 16 * 8) ;

      printf("Result is: %s\n", outputBuff) ;
  }
}
