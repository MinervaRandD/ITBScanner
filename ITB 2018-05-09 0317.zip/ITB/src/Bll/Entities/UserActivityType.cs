﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Asi.Itb.Bll.Entities
{
    public enum UserActivityType
    {
        LogOut = 0,
        LogIn,
        ResetCounter
    }
}
