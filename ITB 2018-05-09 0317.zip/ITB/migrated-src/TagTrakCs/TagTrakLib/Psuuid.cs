namespace TagTrak.TagTrakLib
{
	public struct Psuuid
	{
        //[System.Runtime.InteropServices.DllImport("PSUUID0C.DLL", EntryPoint="?GetSerNum@@YAHPAGK@Z")]
        //public static extern int GetSerNum(byte[] SerNum, int SizeSerNum);
	}
}
