using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("4.0.0.1")]