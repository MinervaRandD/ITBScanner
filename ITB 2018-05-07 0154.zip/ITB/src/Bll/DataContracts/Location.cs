﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Asi.Itb.Bll.DataContracts
{
    public class Location
    {
        public string Name
        {
            get;
            set;
        }

        public string Type
        {
            get;
            set;
        }

        public string Gps
        {
            get;
            set;
        }

        public string Carriers
        {
            get;
            set;
        }
    }
}
