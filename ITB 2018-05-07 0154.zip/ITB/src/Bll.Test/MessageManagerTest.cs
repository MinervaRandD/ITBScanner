﻿using Asi.Itb.Bll;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Asi.Itb.Bll.Entities;
using System.Collections.Generic;

namespace Bll.Test
{
    
    
    /// <summary>
    ///This is a test class for MessageManagerTest and is intended
    ///to contain all MessageManagerTest Unit Tests
    ///</summary>
    [TestClass()]
    public class MessageManagerTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for SaveNewMessage
        ///</summary>
        [TestMethod()]
        public void SaveNewMessageTest()
        {
            MessageManager target = new MessageManager(); // TODO: Initialize to an appropriate value
            Message msg = null; // TODO: Initialize to an appropriate value
            target.SaveNewMessage(msg);
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for PurgeOldReadMessages
        ///</summary>
        [TestMethod()]
        public void PurgeOldReadMessagesTest()
        {
            MessageManager target = new MessageManager(); // TODO: Initialize to an appropriate value
            target.PurgeOldReadMessages();
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for MarkMessageRead
        ///</summary>
        [TestMethod()]
        public void MarkMessageReadTest()
        {
            MessageManager target = new MessageManager(); // TODO: Initialize to an appropriate value
            long msgId = 0; // TODO: Initialize to an appropriate value
            target.MarkMessageRead(msgId);
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for HasUnreadMessages
        ///</summary>
        [TestMethod()]
        public void HasUnreadMessagesTest()
        {
            MessageManager target = new MessageManager(); // TODO: Initialize to an appropriate value
            bool expected = false; // TODO: Initialize to an appropriate value
            bool actual;
            actual = target.HasUnreadMessages();
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetMessages
        ///</summary>
        [TestMethod()]
        public void GetMessagesTest()
        {
            MessageManager target = new MessageManager(); // TODO: Initialize to an appropriate value
            bool unreadOnly = false; // TODO: Initialize to an appropriate value
            List<Message> expected = null; // TODO: Initialize to an appropriate value
            List<Message> actual;
            actual = target.GetMessages(unreadOnly);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for MessageManager Constructor
        ///</summary>
        [TestMethod()]
        public void MessageManagerConstructorTest()
        {
            MessageManager target = new MessageManager();
            Assert.Inconclusive("TODO: Implement code to verify target");
        }
    }
}
