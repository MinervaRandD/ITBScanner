﻿using Asi.Itb.Bll;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Asi.Itb.Bll.Entities;
using System.Collections.Generic;

namespace Bll.Test
{
    
    
    /// <summary>
    ///This is a test class for LocationManagerTest and is intended
    ///to contain all LocationManagerTest Unit Tests
    ///</summary>
    [TestClass()]
    public class LocationManagerTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for SaveLocation
        ///</summary>
        [TestMethod()]
        public void SaveLocationTest()
        {
            LocationManager target = new LocationManager(); // TODO: Initialize to an appropriate value
            Location location = null; // TODO: Initialize to an appropriate value
            target.SaveLocation(location);
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for GetLocations
        ///</summary>
        [TestMethod()]
        public void GetLocationsTest()
        {
            LocationManager target = new LocationManager(); // TODO: Initialize to an appropriate value
            List<Location> expected = null; // TODO: Initialize to an appropriate value
            List<Location> actual;
            actual = target.GetLocations();
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetLocationByGpsData
        ///</summary>
        [TestMethod()]
        public void GetLocationByGpsDataTest()
        {
            LocationManager target = new LocationManager(); // TODO: Initialize to an appropriate value
            double latitude = 0F; // TODO: Initialize to an appropriate value
            double longitude = 0F; // TODO: Initialize to an appropriate value
            Location expected = null; // TODO: Initialize to an appropriate value
            Location actual;
            actual = target.GetLocationByGpsData(latitude, longitude);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for GetLocationByBarcode
        ///</summary>
        [TestMethod()]
        public void GetLocationByBarcodeTest()
        {
            LocationManager target = new LocationManager(); // TODO: Initialize to an appropriate value
            string barcode = string.Empty; // TODO: Initialize to an appropriate value
            Location expected = null; // TODO: Initialize to an appropriate value
            Location actual;
            actual = target.GetLocationByBarcode(barcode);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for DeleteAllLocations
        ///</summary>
        [TestMethod()]
        public void DeleteAllLocationsTest()
        {
            LocationManager target = new LocationManager(); // TODO: Initialize to an appropriate value
            target.DeleteAllLocations();
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for LocationManager Constructor
        ///</summary>
        [TestMethod()]
        public void LocationManagerConstructorTest()
        {
            LocationManager target = new LocationManager();
            Assert.Inconclusive("TODO: Implement code to verify target");
        }
    }
}
